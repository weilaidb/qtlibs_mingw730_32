//#include <iostream>
//#include "cstringpub.h"
//using namespace std;

//int main()
//{
//    cout << "Hello World!" << endl;
//    string input = CStringPub::input();
//    cout << "input:" << input << endl;
//    input = CStringPub::replace(input, " ","");
//    cout << "filter input:" << input << endl;
//    CStringPub::showlength("last input len", input);

//    vector<int> posvec;
//    CStringPub::findpos(input, "ABCD", posvec);
//    CStringPub::printvec(posvec);


//    cout << "replace text" << CStringPub::replace("abcdefaaaaa","a","dddd") << endl;



//    return 0;
//}
