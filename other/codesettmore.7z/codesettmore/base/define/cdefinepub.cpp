#include "cdefinepub.h"

CDefinePub::CDefinePub()
{

}
